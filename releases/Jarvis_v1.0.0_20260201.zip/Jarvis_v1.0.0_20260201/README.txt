# Jarvis AI Assistant v1.0.0

## Quick Start Guide

1. Extract this entire folder to your desired location
2. Double-click `Jarvis.exe` to run
3. The UI will open in your default browser

## System Requirements

- Windows 10/11 (64-bit)
- 4GB RAM minimum (8GB recommended)
- Internet connection (for AI features)

## AI Features

**Option 1: Full AI Mode (Recommended)**
- Install Ollama from: https://ollama.ai
- Run: `ollama pull llama3.2:3b` (or your preferred model)
- Edit config.yaml and set `enabled: true` under llm section

**Option 2: Offline Mode**
- Edit config.yaml and set `enabled: false` under llm section
- All voice commands and custom commands still work
- No AI conversational features

## Configuration

Edit `config.yaml` to customize:
- Wake word (default: "jarvis")
- Voice settings (rate, volume)
- LLM model selection
- Hotkeys and shortcuts

## Custom Commands

Edit `custom_commands.yaml` to add your own commands:
- System commands
- Application launchers
- Scripts and automation
- Timer and reminders

## Support & Documentation

- GitHub: [Your GitHub URL]
- Documentation: See included markdown files
- License: See LICENSE file

## Features

✅ Voice-activated assistant
✅ Natural language processing
✅ Custom command system
✅ Timer and reminders (1-60 minutes)
✅ System automation
✅ File management
✅ Web browser control
✅ And much more!

## Troubleshooting

**Jarvis won't start:**
- Run as Administrator
- Check Windows Defender/Antivirus
- Ensure all files are extracted together

**Voice recognition issues:**
- Check microphone permissions
- Test microphone in Windows settings
- Adjust microphone sensitivity

**AI not responding:**
- Verify Ollama is running
- Check `ollama list` shows your model
- Ensure config.yaml has correct model name

## What's New in v1.0.0

- Enhanced timer system with 12 duration options
- Improved Windows notifications with sounds
- Background timer execution
- Pomodoro timer support (25 minutes)
- Better build system for updates

---

© 2026 Jarvis AI Assistant. All rights reserved.
